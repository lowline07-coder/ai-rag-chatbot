from dotenv import load_dotenv
import streamlit as st

from utils.document_loader import load_pdfs, split_documents
from utils.vector_store import build_retriever
from utils.rag_chain import get_llm, answer_question

load_dotenv()

st.set_page_config(page_title="AI Learning Coach", page_icon="📄")
st.title("📄 AI Learning Coach - RAG Chatbot")

# ---------------- Session State ----------------
if "messages" not in st.session_state:
    st.session_state.messages = []
if "retriever" not in st.session_state:
    st.session_state.retriever = None
if "llm" not in st.session_state:
    st.session_state.llm = get_llm()

# ---------------- Upload & Process ----------------
files = st.file_uploader("Upload PDFs", type="pdf", accept_multiple_files=True)

if files and st.session_state.retriever is None:
    with st.spinner("Processing PDFs..."):
        documents = load_pdfs(files)
        chunks = split_documents(documents)
        st.session_state.retriever = build_retriever(chunks)
    st.success("PDFs processed.")

# ---------------- Chat History ----------------
for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])

# ---------------- Chat ----------------
if st.session_state.retriever:
    query = st.chat_input("Ask a question...")
    if query:
        st.session_state.messages.append({"role": "user", "content": query})
        with st.chat_message("user"):
            st.markdown(query)

        try:
            with st.spinner("Generating answer..."):
                answer, _ = answer_question(
                    st.session_state.retriever, st.session_state.llm, query
                )
        except Exception as e:
            answer = f"Something went wrong: {e}"

        with st.chat_message("assistant"):
            st.markdown(answer)
        st.session_state.messages.append({"role": "assistant", "content": answer})
else:
    st.info("Upload one or more PDF files.")
