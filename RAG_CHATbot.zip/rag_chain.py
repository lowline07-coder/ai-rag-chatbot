from langchain_core.prompts import PromptTemplate
from langchain_groq import ChatGroq

LLM_MODEL = "openai/gpt-oss-20b"

PROMPT = PromptTemplate(
    input_variables=["context", "question"],
    template="""You are a helpful AI assistant.
Answer only from the context.
If answer is unavailable, say: I couldn't find this information in the uploaded documents.

Context:
{context}

Question:
{question}

Answer:""",
)


def get_llm():
    return ChatGroq(model=LLM_MODEL, temperature=0)


def answer_question(retriever, llm, question):
    """Retrieve relevant chunks and generate an answer from them only."""
    docs = retriever.invoke(question)
    context = "\n\n".join(d.page_content for d in docs)
    response = llm.invoke(PROMPT.invoke({"context": context, "question": question}))
    return response.content, docs
