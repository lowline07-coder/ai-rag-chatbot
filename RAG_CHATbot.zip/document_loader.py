import os
import tempfile

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter


def load_pdfs(uploaded_files):
    """Read Streamlit-uploaded PDF files and return a list of LangChain documents."""
    documents = []
    for pdf in uploaded_files:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(pdf.read())
            tmp_path = tmp.name
        try:
            documents.extend(PyPDFLoader(tmp_path).load())
        finally:
            os.remove(tmp_path)  # clean up the temp file
    return documents


def split_documents(documents, chunk_size=1000, chunk_overlap=200):
    """Split documents into overlapping chunks for embedding."""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )
    return splitter.split_documents(documents)
